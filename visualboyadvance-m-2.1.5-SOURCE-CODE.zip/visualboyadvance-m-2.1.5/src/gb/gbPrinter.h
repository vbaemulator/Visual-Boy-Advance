#ifndef GBPRINTER_H
#define GBPRINTER_H

#include "../System.h"

uint8_t gbPrinterSend(uint8_t b);

#endif // GBPRINTER_H
